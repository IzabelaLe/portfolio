/**
 *
 *  @author Leszczyńska Izabela S16499
 *
 */

package zad2;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class CustomersPurchaseSortFind {
	private List<Purchase> purchases;	
	
	public void readFile(String fileName) {
		purchases = new ArrayList<>();
		List<String> lines = null;
		try { 
			lines = Files.readAllLines(Paths.get(fileName), StandardCharsets.UTF_8); 
		} catch (IOException e) {e.printStackTrace();}
		for (String line : lines) {
			String[] str = line.split(";");
			String[] str2 = str[1].split("\\s+");
			purchases.add(new Purchase(str[0],str2[0],str2[1],str[2],str[3],str[4]));
		}
	}
	
	public void showSortedBy(String option) {
		Comparator<Purchase> c = null;
		boolean ifCost = false;
		if(option.equals("Nazwiska")) {
			c = new Comparator<Purchase>() {
				@Override
				public int compare(Purchase p1, Purchase p2) {
					int i = p1.getSurname().compareTo(p2.getSurname());
					if(i==0)
						i = p1.getClientID().compareTo(p2.getClientID());
					return i;
				}
			};
		}
		if(option.equals("Koszty")) {
			ifCost = true;
			c = new Comparator<Purchase>() {
				@Override
				public int compare(Purchase p1, Purchase p2) {
					int i = (-1)*p1.getCost().compareTo(p2.getCost());
					if(i==0)
						i = p1.getClientID().compareTo(p2.getClientID());
					return i;
				}
			};
		}
		purchases.sort(c);
		System.out.println(option);
		for (Purchase p : purchases)
			System.out.println(p.toString(ifCost));
	}
	
	public void showPurchaseFor(String ID) {
		System.out.println("Klient "+ID);
		for (Purchase p : purchases) {
			if(p.getClientID().equals(ID))
				System.out.println(p.toString(false));
		}
	}
}
