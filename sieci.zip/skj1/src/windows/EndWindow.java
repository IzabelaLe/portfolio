package windows;

import java.awt.Dimension;
import java.awt.GridLayout;
import java.util.Map;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;

public class EndWindow extends JFrame {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public EndWindow(String myName, Map<String,Integer> won, Map<String,Integer> lost) {
		System.out.println("EndWindow created");
		setTitle("Podsumowanie gry ("+myName+")");
		setLayout(new GridLayout(1,1));
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setPreferredSize(new Dimension(400, 500));
		String[] colNames = {"Przeciwnik", "Wygranych", "Przegranych"};
		Object[][] tab = new Object[won.keySet().size()][3];
		int count = 0;
		for(String opp : won.keySet()) {
			tab[count][0] = opp;
			tab[count][1] = won.get(opp);
			tab[count][2] = lost.get(opp);
		}
		for( String s : colNames) {
			System.out.println(s);
		}
		for(Object[] row : tab) {
			for(Object o : row)
				System.out.println(o);
		}
		add(new JScrollPane(new JTable(tab, colNames)));
		pack();
		setVisible(true);
	}
}
