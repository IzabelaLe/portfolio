package windows;



import java.awt.Dimension;
import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

import join.Initiator;
import join.Joiner;
import main.Game;

public class JoinWindow extends JFrame {
	
	private Game game;
	private boolean joinSucceeded;
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public JoinWindow() {
		setTitle("Dołącz do gry");
		setLayout(new GridLayout(10,1));
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setPreferredSize(new Dimension(400,600));
		
		JTextField textEditor1 = new JTextField();
		add(textEditor1);
		JLabel editorLabel1 = new JLabel("Podaj swoją nazwę gracza");
		editorLabel1.setLabelFor(textEditor1);
		add(editorLabel1);
		JTextField textEditor2 = new JTextField();
		add(textEditor2);
		JLabel editorLabel2 = new JLabel("Podaj swój numer portu");
		editorLabel2.setLabelFor(textEditor2);
		add(editorLabel2);
		JTextField textEditor3 = new JTextField();
		add(textEditor3);
		JLabel editorLabel3 = new JLabel("Podaj IP agenta wprowadzającego");
		editorLabel3.setLabelFor(textEditor3);
		add(editorLabel3);
		JTextField textEditor4 = new JTextField();
		add(textEditor4);
		JLabel editorLabel4 = new JLabel("Podaj port agenta wprowadzającego");
		editorLabel4.setLabelFor(textEditor4);
		add(editorLabel4);
		
		Joiner join = new Joiner(textEditor1, textEditor2, textEditor3, textEditor4);
		JButton sendButton = new JButton("Dołącz");
		sendButton.addActionListener(e -> {
			join.invoke();
			this.game = join.getGame();
			this.joinSucceeded = join.getIfSuccess();
		});
		add(sendButton);
		
		Initiator init = new Initiator(textEditor1, textEditor2);
		JButton create = new JButton("Utwórz nową grę");
		create.addActionListener(e -> {
			init.invoke();
			this.game = init.getGame();
			this.joinSucceeded = init.getIfSuccess();
		});
		add(create);
		
		pack();
		setVisible(true);
		
	}

	public Game getGame() {
		return game;
	}

	public boolean isJoinSucceeded() {
		return joinSucceeded;
	}
	
	
	
}
