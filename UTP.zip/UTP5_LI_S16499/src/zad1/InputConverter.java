package zad1;

import java.util.function.Function;

public class InputConverter<E> {
	private E input;
	
	public InputConverter(E input){
		this.input = input;
	}
	
	public <R> R convertBy(Function<E,R> f) {
		return f.apply(this.input);
	}
	
	public <R,T> R convertBy(Function<E,T> f, Function<T,R> f2) {
		return f2.apply(f.apply(this.input));
	}
	
	public <R,T1,T2> R convertBy(Function<E,T1> f, Function<T1,T2> f2, Function<T2,R> f3) {
		return f3.apply(f2.apply(f.apply(this.input)));
	}
	
	public <R,T1,T2,T3> R convertBy(Function<E,T1> f, Function<T1,T2> f2, Function<T2,T3> f3, Function<T3,R> f4) {
		return f4.apply(f3.apply(f2.apply(f.apply(this.input))));
	}

}
