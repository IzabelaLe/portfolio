package main;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.lang.ref.Reference;
import java.lang.ref.WeakReference;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;
import java.util.Vector;
import java.util.concurrent.TimeUnit;

import threads.SocketThread;
import windows.EndWindow;
import windows.ErrorWindow;
import windows.GameWindow;
import windows.TurnWindow;

public class Game {
	public String myName;
	public ServerSocket server;
	public LinkedList<String> toPlayQueue;
	private LinkedList<String> activeTurns;
	public Map<String,Socket> players;
	private Map<String,Integer> won;
	private Map<String,Integer> lost;
	public WeakReference<GameWindow> windowref;


	public Game(Map<String,Socket> m, ServerSocket server, String myName) { 
		this.players = m;
		this.server = server;
		this.myName = myName;
		won = new HashMap<>();
		lost = new HashMap<>();
		toPlayQueue = new LinkedList<>();
		activeTurns = new LinkedList<>();
		for ( String name : players.keySet()) {
			won.put(name, new Integer(0));
			lost.put(name, new Integer(0));
			SocketThread t = new SocketThread(players.get(name), new WeakReference<>(this));
			t.start();
		}
		Thread queueThread = new Thread() {
			@Override
			public void run() {
				while(true) {
					try {
						TimeUnit.SECONDS.sleep(1);
					} catch (InterruptedException e) {
						//Auto-generated catch block
						e.printStackTrace();
					}
					while(!toPlayQueue.isEmpty()) {
						newTurn(toPlayQueue.removeFirst());
					}
				}
			}
		};
		queueThread.start();
		
	}
	
	public void newTurn(String opp) {
		activeTurns.add(opp);
		Reference<Game> selfref = new WeakReference<>(this);
		Turn t = null;
		try{
			t = new Turn(selfref, opp);
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}
		Reference<Turn> turnref = new WeakReference<>(t);
		@SuppressWarnings("unused")
		TurnWindow tw = new TurnWindow(turnref, opp);
		t.receiveOppNum();
	}
	
	public void requestTurn(String opp) {
		Socket s = players.get(opp);
		BufferedWriter dOut;
		try {
			dOut = new BufferedWriter(new OutputStreamWriter(s.getOutputStream()));
			dOut.write("PLAY");
			dOut.newLine();
			dOut.flush();
		} catch (NullPointerException | IOException e) {
			System.out.println("request error "+e.getMessage());
		}
		
	}
	
	public void addPlayer(String name, Socket s) {
		players.put(name, s);
		won.put(name, new Integer(0));
		lost.put(name, new Integer(0));
		SocketThread st = new SocketThread(s, new WeakReference<>(this));
		st.start();
		windowref.get().refreshComboBox();
	}
	
	public void doJoin(String name, Socket s) {
		addPlayer(name, s);
		sendToAll("NEWPLAYER/"+name+s.getInetAddress().toString()+"/"+s.getPort(), name);
	}
	
	public void quit() {
		if(!(activeTurns.isEmpty()&&toPlayQueue.isEmpty())) {
			@SuppressWarnings("unused")
			ErrorWindow ew = new ErrorWindow("Rozegraj aktywne tury przed zakończeniem gry");
			return;
		}
		boolean allPlayed  = true;
		String notPlayedWith = null;
		for(String player : players.keySet()) {
			if((won.get(player)==0)&&(lost.get(player)==0)) {
				allPlayed = false;
				notPlayedWith = player;
				break;
			}
		}
		if(!allPlayed) {
			@SuppressWarnings("unused")
			ErrorWindow ew = new ErrorWindow("Rozegraj turę z "+notPlayedWith);
			return;
		}
		
		sendToAll("QUIT" ,"");
		@SuppressWarnings("unused")
		EndWindow ew = new EndWindow(myName, this.won, this.lost);
		windowref.get().dispose();
	}
	
	public void doQuit(String name) {
		players.remove(name);
		won.remove(name);
		lost.remove(name);
		windowref.get().refreshComboBox();
	}
	
	public void won(String opp) {
		increment(won, opp);
	}
	
	public void lost(String opp) {
		increment(lost, opp);
	}
	
	private void increment(Map<String,Integer> map, String key) {
		Integer val = map.get(key);
		val = new Integer(val.intValue()+1);
		map.replace(key, val);
	}
	
	public Vector<String> getPlayers(){
		return new Vector<>(players.keySet());
	}

	public void setWindow(WeakReference<GameWindow> ref) {
		this.windowref = ref;
	}

	private void sendToAll(String str, String exceptFor) {
		for (String name : players.keySet()) {
			if(!name.equals(exceptFor)) {
				BufferedWriter dOut;
				try {
					dOut = new BufferedWriter(new OutputStreamWriter(players.get(name).getOutputStream()));
					dOut.write(str);
					dOut.flush();
					System.out.println("sending "+str+" to "+name);
				} catch (IOException e) { }
			}
		}
	}

	public void endTurn(String opp) {
		activeTurns.remove(opp);
	}
	
	
}
