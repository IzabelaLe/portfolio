package windows;

import java.awt.GridLayout;

import javax.swing.JFrame;
import javax.swing.JLabel;

public class ResultWindow extends JFrame {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ResultWindow(String opp, String content) {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setTitle("Wynik tury z "+opp);
		setLayout(new GridLayout(1,1));
		setResizable(false);
		this.setSize(400,100);
		JLabel text = new JLabel(content);
		add(text);
		this.setVisible(true);
	}
}
