package zad2;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class Futil {

	public static void processDir(String dirName, String resultFileName) {
		Path start = Paths.get(dirName);
		File f = new File(resultFileName);
		try {
			BufferedWriter out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(f), "UTF-8"));
			BufferedReader in;
			try(DirectoryStream<Path> stream = Files.newDirectoryStream(start)){
				for (Path file : stream) {
					in = new BufferedReader( new InputStreamReader(new FileInputStream(new File(file.toString())), "Cp1250"));
					String str;
					while((str = in.readLine()) !=null) 
						out.append(str+"\n");
				}
			}
			out.flush();
			out.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
