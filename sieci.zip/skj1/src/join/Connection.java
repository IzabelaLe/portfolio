package join;

import java.io.BufferedReader;
import java.io.BufferedWriter;

import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import main.Game;

public class Connection {
	private String name;
	private InetAddress ip;
	private Socket socket;
	private ServerSocket server;
	private String configData;
	
	public Connection(String name, int port, String iip, int iport) throws IOException, IllegalArgumentException {
		this.name = name;
		setIP();
		System.out.println("My port: "+port);
		server = new ServerSocket(port, 10, ip);
		socket = new Socket(iip, iport);
		socket.setSoTimeout(100000);
	}
	
	public Connection(String name, int port) throws IOException, IllegalArgumentException {
		this.name = name;
		setIP();
		System.out.println("My port: "+port);
		server = new ServerSocket(port, 10, ip);
	}
	
	private void setIP() {
		Enumeration<NetworkInterface> interfaces = new MyEnum<>();
		try {
			interfaces = NetworkInterface.getNetworkInterfaces();
		} catch (SocketException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		boolean correctIP = false;
		while(interfaces.hasMoreElements() && !correctIP) {
			Enumeration<InetAddress> addresses = interfaces.nextElement().getInetAddresses();
			while(addresses.hasMoreElements() && !correctIP) {
				ip = addresses.nextElement();
				correctIP = check(ip);
			}
		}
		System.out.println("My IP: "+ip.toString());
	}
	
	private boolean check(InetAddress ip) {
		byte[] ipByte = ip.getAddress();
		if(ipByte[0]==127) return false;
		if(ipByte[0]==192 && ipByte[1]==168) return false;
		if(ipByte[0]==10) return false;
		if(ipByte[0]==172 && (ipByte[1]>15 && ipByte[1]<32)) return false;
		if(ipByte[0]==169 && ipByte[1]==254) return false;
		if(ipByte[0]>223 && ipByte[0]<240) return false;
		boolean mark = true;
		for (byte b : ipByte) {
			if(b!=255) {
				mark = false;
				break;
			}
		}
		if(mark) return false;
		if(ipByte.length>4) return false;
		return true;
	}
	
	public boolean join() throws IOException {
		boolean success = false;
		String reply = null;
		BufferedReader dIn = new BufferedReader(new InputStreamReader(socket.getInputStream()));
		BufferedWriter dOut = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
		dOut.write("JOIN");
		dOut.newLine();
		dOut.flush();
		reply = dIn.readLine();
		success = reply.equals("JOINCONFIRMED");
		if (success) {
			dOut.write("NEWPLAYER/"+name);
			dOut.newLine();
			dOut.flush();
			configData = dIn.readLine();
			System.out.println("configData "+configData);
		}
		return success;
		
	}
	
	
	public Game createGame() {
		List<String[]> l = new LinkedList<>();
		for (String s : configData.split("//")) {
			l.add(s.split("/"));
		}
		Map<String,Socket> players = new HashMap<>();
		int connectPort = socket.getPort();
		for (String[] s : l) {
			try {
				Socket sock;
				int port = Integer.parseInt(s[2]);
				if(("/"+s[1]).equals(ip.toString())&&port==connectPort)
					sock = socket;
				else
					sock = new Socket(s[1], port);
				sock.setSoTimeout(100000);
				players.put(s[0], sock);
			} catch (NumberFormatException | IOException e) {
				System.out.println("Socket add failed: "+s[1]+" "+s[2]);
			}
		}
		return new Game(players, server, name);
		
	}
	
	public Game emptyGame() {
		return new Game(new HashMap<String,Socket>(), server, name);
	}
	
}
