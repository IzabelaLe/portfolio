/**
 *
 *  @author Leszczyńska Izabela S16499
 *
 */

package zad1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Main {
public static void main(String[] args) {
	  try {
	  Stream<String> words = new BufferedReader(new InputStreamReader(new URL("http://wiki.puzzlers.org/pub/wordlists/unixdict.txt").openStream())).lines();
	  Map<String, List<String>> anagrams = words.collect(Collectors.groupingBy(str -> {
		  char[] arr = str.toCharArray();
		  Arrays.sort(arr);
		  return new String(arr);
	  }));
	  Map<Integer, List<String>> lengths = anagrams.keySet().stream().collect(Collectors.groupingBy(str -> anagrams.get(str).size())) ;
	  lengths.get(lengths.keySet().stream().mapToInt(v->v).max().getAsInt()).stream().forEach(key -> {
		  anagrams.get(key).stream().forEach( word -> {
			  StringBuilder sb = new StringBuilder().append(word);
			  anagrams.get(key).stream().forEach( ana -> {if(!ana.equals(word)) sb.append(" "+ana);});
			  System.out.println(sb.toString());
		  });
	  });
	  } catch (IOException e) {}
  }
}