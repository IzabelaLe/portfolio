/**
 *
 *  @author Leszczyńska Izabela S16499
 *
 */

package zad1;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.List;

public class Anagrams {
	
	List<List<String>> anagrams;

	public Anagrams(String path) {
		anagrams = new LinkedList<>();
		List<String> lines = null;
		try { 
			lines = Files.readAllLines(Paths.get(path), StandardCharsets.UTF_8); 
		} catch (IOException e) {e.printStackTrace();}
		List<String> words = new LinkedList<>();
		for( String s : lines) {
			String[] array = s.split("\\s");
			for ( String sa : array) {
				words.add(sa);
			}
		}
		for(String s : words) {
			boolean foundAnagram = false;
			for( List<String> ana : anagrams ) {
				foundAnagram = ifAnagrams(s, ana.get(0));
				if(foundAnagram) {
					ana.add(s);
					break;
				}
			}
			if(!foundAnagram) {
				List<String> l = new LinkedList<>();
				l.add(s);
				anagrams.add(l);
			}
		}
	}
	
	private boolean ifAnagrams(String s1, String s2) {
		if(s1.length()!=s2.length())
			return false;
		int len = s1.length();
		char[] word1 = s1.toCharArray();
		char[] word2 = s2.toCharArray();
		boolean found = false;
		int count = 0;
		
		for(int i = 0; i<len; i++) {
			found = false;
			for(int j = 0; j<len && !found; j++) {
				if(word2[j]==word1[i]) {
					found = true;
					word2[j] = '\0';
					count++;
				}
			}
		}
		return (count==len);
	}

	public List<List<String>> getSortedByAnQty() {
		Comparator<List<String>> c = new Comparator<List<String>>(){
			@Override
			public int compare(List<String> arg0, List<String> arg1) {
				int len = -Integer.compare(arg0.size(), arg1.size());
				if(len==0)
					return arg0.get(0).compareTo(arg1.get(0));
				else 
					return len;
			}
		};
		anagrams.sort(c);	
		return anagrams;
	}

	public String getAnagramsFor(String string) {
		List<String> anagramList = null;
		boolean found = false;
		for (List<String> l : anagrams ) {
			for(String s : l ) {
				if(s.equals(string)) {
					anagramList = l;
					found = true;
					break;
				}
			}
			if(found)
				break;
		}
		anagramList.remove(string);
		return string+": "+anagramList.toString();
	}
}  
