package main;

import java.lang.ref.Reference;
import java.lang.ref.WeakReference;
import java.util.concurrent.TimeUnit;

import threads.ServerThread;
import windows.GameWindow;
import windows.JoinWindow;

public class Main {
	private static Game game;
	
	public static void main(String[] args) throws InterruptedException {
		JoinWindow jw = new JoinWindow();
		Thread waitThread = new Thread() {
			@Override
			public void run() {
				while(!jw.isJoinSucceeded()) {	
					try {
						TimeUnit.SECONDS.sleep(1);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				} 
				game = jw.getGame();
				jw.dispose();
				main2();
			}
		};
		waitThread.start();
		
		
	}
	
	private static void main2() {
		Reference<Game> ref = new WeakReference<Game>(game);
		
		ServerThread t = new ServerThread(ref);
		t.start();
		
		Thread queueThread = new Thread() {
			@Override
			public void run() {
				while(true) {
					while(!game.toPlayQueue.isEmpty()) {
						String player = game.toPlayQueue.removeFirst();
						game.newTurn(player);
					}
				}
			}
		};
		queueThread.start();
		
		GameWindow gw = new GameWindow(ref);
		WeakReference<GameWindow> ref2 = new WeakReference<>(gw);
		game.setWindow(ref2);
	}
}