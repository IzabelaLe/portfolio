package zad2;

import java.io.IOException;
import java.util.function.Function;

@FunctionalInterface
public interface ThrowingFunction<T,R,E extends IOException> {
	public R apply(T arg) throws IOException;
	
	public static <T,R,E extends IOException> Function<T,R> wrapper(ThrowingFunction<T,R,E> f) {
		return arg -> {
			try {
				return f.apply(arg);
			} catch (IOException e) {
				throw new RuntimeException(e);
			}
		};
	}
}
