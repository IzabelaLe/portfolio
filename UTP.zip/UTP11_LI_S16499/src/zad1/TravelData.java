package zad1;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class TravelData {
	private List<String> offersList;
	private String[] langMap = {"pl_PL", "en_US"};
	private String[][] placesMap = {{"morze", "sea"}, {"jezioro", "lake"}, {"góry", "mountains"}};
	private String[][] countriesMap = {{ "Polska", "Poland"}, {"Niemcy", "Germany"},{ "Włochy", "Italy"},
			{ "Stany Zjednoczone Ameryki", "United States"}, {"Japonia", "Japan"}};

	public TravelData(File dataDir) {
		offersList = new ArrayList<>();
		File[] listOfFiles = dataDir.listFiles();
		for(File f : listOfFiles) {
			BufferedReader br = null;
			try {
				br = new BufferedReader(new InputStreamReader(new FileInputStream(f)));
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			String line;
			try {
				while((line = br.readLine()) !=null)
					offersList.add(line);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		//TODO dodaj przetlumazone do listy 
		List<String> addList = new ArrayList<>();
		for(String s : offersList) {
			for(String loc : langMap) {
				String[] line = s.split("\\t");
				if(!line[0].equals(loc)) {
					try {
						int locIndex = locIndex(loc);
						line[0] = loc;
						line[1] = countriesMap[findRow(line[1], countriesMap)][locIndex];
						line[4] = placesMap[findRow(line[4], placesMap)][locIndex];
					} catch (Exception e) {
						System.out.println(e.getMessage()+" "+s);
					}
					
					String result = "";
					int count = 0;
					for(String str : line) {
						if(count<line.length-1)
							result = result + str + "\t";
						else
							result = result + str;
					}
					addList.add(result);
				}
			}
		}
		offersList.addAll(addList);
		
		
		
	}

	public List<String> getOffersDescriptionsList(String locale, String dateFormat) {
		List<String> result = new ArrayList<>();
		for (String line : offersList) {
			if(line.startsWith(locale)) {
				String[] els = line.split("\\t");
				line = "";
				int count = 0;
				for(String str : els) {
					count++;
					if(count>1) {
						if(count<els.length)
							line = line + str + " ";
						else
							line = line + str;
					}
				}
				result.add(line);
			}
		}
		return result; //dateformat?
	}
	
	public List<String> getData(){
		return offersList;
	}

	
	private int findRow(Object o, Object[][] arr) throws Exception {
		for (int i = 0; i< arr.length; i++) {
			for (int j = 0; j< arr[0].length; j++) {
				if(arr[i][j].equals(o)) return i;
			}
		}
		throw new Exception("Not found "+o.toString());
	}
	
	private int locIndex(String loc) {
		if(loc.equals("pl_PL")) return 0;
		if(loc.equals("pl")) return 0;
		if(loc.equals("en_US")) return 1;
		if(loc.equals("en_GB")) return 1;
		return 0;
	}
	
}
