package join;

import java.util.Enumeration;

public class MyEnum<T> implements Enumeration<T> {
	
	public MyEnum() {
		super();
	}

	@Override
	public boolean hasMoreElements() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public T nextElement() {
		// TODO Auto-generated method stub
		return null;
	}

	

}
