package zad2;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.function.BiFunction;
import java.util.function.Predicate;

public class ProgLang {
	private Map<String,List<String>> langs;
	private Map<String,List<String>> progs;

	public ProgLang(String path) {
		List<String> lines = null;
		langs = new LinkedHashMap<>();
		try { 
			lines = Files.readAllLines(Paths.get(path), StandardCharsets.UTF_8); 
		} catch (IOException e) {e.printStackTrace();}
		//wg jezykow, jak w pliku
		for(String s : lines ) {
			String[] params = s.split("\\t");
			List<String> names = new LinkedList<>();
			for(int i = 1; i<params.length; i++) {
				if(!names.contains(params[i]))
					names.add(params[i]);
			}
			langs.put(params[0], names);
		}
		//wg programistow
		progs = new LinkedHashMap<>();
		for(String lang : langs.keySet()) {
			for(String  person : langs.get(lang)) {
				if(progs.containsKey(person)) {
					List<String> l = progs.get(person);
					if(!l.contains(person))
						l.add(lang);
					progs.replace(person, l);
				} else {
					List<String> l = new LinkedList<String>();
					l.add(lang);
					progs.put(person, l);
				}
			}
		}
	}

	public Map<String, List<String>> getLangsMap() {
		return langs;
	}

	public Map<String, List<String>> getProgsMap() {
		return progs;
	}
	
	public Map<String, List<String>> getLangsMapSortedByNumOfProgs() {
		return sorted(this.langs, ((entry1, entry2) -> {
			int cmp = Integer.compare(entry2.getValue().size(), entry1.getValue().size());
			if(cmp==0)
				cmp = entry1.getKey().compareTo(entry2.getKey());
			return cmp;
			}));
	}
	
	public Map<String, List<String>> getProgsMapSortedByNumOfLangs() {
		return sorted(this.progs, ((entry1, entry2) -> {
			int cmp = Integer.compare(entry2.getValue().size(), entry1.getValue().size());
			if(cmp==0)
				cmp = entry1.getKey().compareTo(entry2.getKey());
			return cmp;
			}));
	}
	
	public Map<String, List<String>> getProgsMapForNumOfLangsGreaterThan(int n) {
		return filtered(this.progs, (entry -> (entry.getValue().size() > n)));
	}
	
	public static <K,V> Map<K,V> sorted(Map<K,V> m, BiFunction<Entry<K,V>,Entry<K,V>,Integer> f){
		Map<K,V> result = new LinkedHashMap<>();
		Comparator<Entry<K,V>> c = new Comparator<Entry<K,V>>(){
			@Override
			public int compare(Entry<K, V> e1, Entry<K, V> e2) {
				return f.apply(e1,e2);
			}
			
		};
		List<Entry<K,V>> entries = new ArrayList<>();
		for ( Entry<K,V> e : m.entrySet())
			entries.add(e);
		entries.sort(c);
		for(Entry<K,V> e : entries) {
			result.put(e.getKey(), e.getValue());
		}
		return result;
	}
	
	public static <K,V> Map<K,V> filtered(Map<K,V> m, Predicate<Entry<K,V>> p){
		Map<K,V> result = new LinkedHashMap<>();
		for(Entry<K, V> e : m.entrySet()) {
			if(p.test(e))
				result.put(e.getKey(), e.getValue());
		}
		return result;
	}

}
