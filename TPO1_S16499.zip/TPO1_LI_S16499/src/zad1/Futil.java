package zad1;

import java.io.IOException;
import java.nio.CharBuffer;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.charset.Charset;
import java.nio.file.FileVisitResult;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.StandardOpenOption;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.EnumSet;
import java.util.Set;

public class Futil {

	public static void processDir(String dirName, String resultFileName) {
		Charset charsetIn = Charset.forName("Cp1250");
		Charset charsetOut = Charset.forName("UTF-8");
		Set<StandardOpenOption> optionsIn = EnumSet.of(StandardOpenOption.READ);
	    Set<StandardOpenOption> optionsOut = EnumSet.of(StandardOpenOption.READ, StandardOpenOption.WRITE, StandardOpenOption.CREATE);
		
		try {
			
			FileChannel out = FileChannel.open(Paths.get(resultFileName), optionsOut);
			Files.walkFileTree(Paths.get(dirName), new SimpleFileVisitor<Path>() {
				int beg = 0;
			     @Override
			     public FileVisitResult visitFile(Path file, BasicFileAttributes attrs)
			         throws IOException
			     {
			    	 FileChannel in = FileChannel.open(file, optionsIn);
			    	 MappedByteBuffer bufferIn = in.map(FileChannel.MapMode.READ_ONLY, 0, in.size());
			    	 CharBuffer cb  = charsetIn.decode(bufferIn);
			    	 MappedByteBuffer bufferOut = out.map(FileChannel.MapMode.READ_WRITE, beg, beg+cb.length());
			    	 beg = beg+cb.length();
			    	 bufferOut.put(charsetOut.encode(cb));
			    	 return FileVisitResult.CONTINUE;
			     }
			 });
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
