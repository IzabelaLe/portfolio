/**
 *
 *  @author Leszczyńska Izabela S16499
 *
 */

package zad2;


public class Purchase {
	private String clientID;
	private String surname;
	private String name;
	private String product;
	private String price;
	private String quantity;
	private double cost;
	private String separator = ";";
	
	public Purchase(String clientID, String surname, String name, String product, String price, String quantity) {
		this.clientID = clientID;
		this.surname = surname;
		this.name = name;
		this.product = product;
		this.price = price;
		this.quantity = quantity;
		try {
			this.cost = Double.parseDouble(price)*Double.parseDouble(quantity);
		} catch (NumberFormatException e) {
			System.out.println("NumberFormatException when calculating cost");
		}
	}
	
	public String getClientID() {
		return clientID;
	}
	public String getSurname() {
		return surname;
	}
	public String getName() {
		return name;
	}
	public String getProduct() {
		return product;
	}
	public String getPrice() {
		return price;
	}
	public String getQuantity() {
		return quantity;
	}
	
	public Double getCost() {
		return new Double(cost);
	}
	
	public String toString(boolean ifCost) {
		String s = clientID+separator+surname+" "+name+separator+product+separator+price+separator+quantity;
		if(ifCost)
			s = s+" (koszt: "+cost+")";
		return s;
	}
}
