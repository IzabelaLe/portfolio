package join;

import java.io.IOException;
import java.net.InetAddress;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JTextField;

import main.Game;
import windows.ErrorWindow;
@SuppressWarnings("unused")

public class Initiator implements ClickFun {
	private JTextField NAME;
	private JTextField PORT;
	private String name;
	private int port;
	private String iip;
	private int iport;
	private boolean error;
	private Game game;

	
	public Initiator(JTextField NAME, JTextField PORT) {
		this.NAME = NAME;
		this.PORT = PORT;
		this.error = true;
	}
	
	private void getParameters() {
		this.error = false;
		this.name = this.NAME.getText();
		try {
			this.port = Integer.parseInt(PORT.getText());
		} catch (NumberFormatException e) {
			ErrorWindow ew = new ErrorWindow("Podaj liczbę w polu PORT");
			this.error = true;
		}
	}
	
	
	public void invoke() {
		getParameters();
		Connection c;
		if(!error) {
				try {
					c = new Connection(name, port);
					this.game = c.emptyGame();
				} catch (IOException e) {
					ErrorWindow ew = new ErrorWindow("Nie udało się utworzyć gry. Spróbuj ponownie.");
					ew.setVisible(true);
					this.error = true;
				}
		}
	}
	
	public Game getGame() {
		return this.game;
	}

	public boolean getIfSuccess() {
		return !this.error;
	}
}

