package main;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.lang.ref.Reference;
import java.net.Socket;
import java.util.concurrent.TimeUnit;

import windows.ResultWindow;

public class Turn {
	private String opp;
	private Reference<Game> ref;
	private BufferedWriter dOut;
	private BufferedReader dIn;
	private int oppNum;
	private int myNum;
	private boolean ifOppNumSet;
	private boolean ifMyNumSet;
	
	public Turn(Reference<Game> ref, String opp) throws IOException {
		this.ref = ref;
		this.opp = opp;
		this.ifOppNumSet = false;
		Socket s = ref.get().players.get(opp);
		dIn = new BufferedReader(new InputStreamReader(s.getInputStream()));
		dOut = new BufferedWriter(new OutputStreamWriter(s.getOutputStream()));
		Thread t = new Thread() {
			@Override
			public void run() {
				while(!(ifOppNumSet&&ifMyNumSet)){ 
					try {
						TimeUnit.SECONDS.sleep(1);
					} catch (InterruptedException e) {
						//Auto-generated catch block
						e.printStackTrace();
					}
				}
				try {
					@SuppressWarnings("unused")
					ResultWindow rw;
					if (play())
						rw = new ResultWindow(opp, "WYGRANA! :)");
					else
						rw = new ResultWindow(opp, "Przegrana");
					ref.get().endTurn(opp);
				} catch (IOException e) { 
					System.out.println("play method error "+e.getMessage());
				}
			}
		};
		t.start();
	}
	
	public void receiveOppNum() {
		Thread oppNumThread = new Thread() {
			@Override
			public void run() {
				while(!ifOppNumSet) {
					try {
						oppNum = Integer.parseInt(dIn.readLine());
						ifOppNumSet = true;
					} catch (NumberFormatException | IOException e) {
						System.out.println("oppnumthread error "+e.getMessage());
					}
				}
			}
		};
		oppNumThread.start();
	}
	
	public void sendMyNum() {
		try {
			dOut.write(Integer.toString(myNum));
			dOut.newLine();
			dOut.flush();
		} catch (IOException e) {
			System.out.println("sendmynum error "+e.getMessage());
		}
		
	}
	
	public boolean play() throws IOException {
		//kto zaczyna
		boolean orderEstablished = false;
		boolean iBegin = false;
		while(!orderEstablished) {
			double d = Math.random();
			iBegin = (d<0.5);
			dOut.write(Boolean.toString(iBegin));
			dOut.newLine();
			dOut.flush();
			orderEstablished = (Boolean.parseBoolean(dIn.readLine())!=iBegin);
			//powinno zadziałać z prawdopodobieństwem 0.5
		}
		
		//rozgrywka
		boolean iWin;
		int sum = myNum+oppNum;
		sum = sum%2;
		iWin = (sum==1 && iBegin);
		
		//dodanie gry do historii
		if(iWin)
			ref.get().won(opp);
		else
			ref.get().lost(opp);
		
		//funkcja zwraca czy gracz wygrał
		return iWin;
	}

	public void setMyNum(int myNum) {
		this.ifMyNumSet = true;
		this.myNum = myNum;
	}
	
}
