package zad1;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.function.BiConsumer;
import java.util.function.Function;

public class XList<T> extends ArrayList<T> {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@SafeVarargs
	public XList(T... vals) {
		super();
		for ( T t : vals)
			this.add(t);
	}
	
	public XList(Collection<T> collection) {
		super(collection);
	}


	
	
	@SafeVarargs
	public static <T> XList<T> of(T... array) {
		return new XList<>(array);
	}
	
	public static <T> XList<T> of(Collection<T> collection) {
		return new XList<>(collection);
	}
	
	public static XList<String> charsOf(String s){
		List<String> list = new ArrayList<>();
		for (char c : s.toCharArray())
			list.add(Character.toString(c));
		return new XList<>(list);
	}
	
	public static XList<String> tokensOf(String s, String regex){
		List<String> list = new ArrayList<>();
		for (String el : s.split(regex))
			list.add(el);
		return new XList<>(list);
	}
	
	public static XList<String> tokensOf(String s){
		return tokensOf(s, "\\s+");
	}

	public XList<T> union(Collection<T> addList) {
		XList<T> newList = this.clone();
		newList.addAll(addList);
		return newList;
	}
	
	public XList<T> union(T[] l) {
		XList<T> addList = new XList<>(l);
		return union(addList);
	}
	
	public XList<T> diff(Collection<T> subtract) {
		XList<T> newList = this.clone();
		newList.removeAll(subtract);
		return newList;
	}
	
	public XList<T> unique(){
		XList<T> newList = new XList<>();
		for (T element : this) {
			if(newList.contains(element)) {}
			else newList.add(element);
		}
		return newList;
	}
	
	public <Q> XList<XList<Q>> combine(){ 
		XList<XList<Q>> result = new XList<XList<Q>>();
		XList<Collection<Q>> cl = (XList<Collection<Q>>) this;
		XList<XList<Q>> toCombine = new XList<XList<Q>>();
		for (Collection<Q> c : cl )
			toCombine.add(new XList<>(c));
		int bigLen = toCombine.size();
		int[] lens = new int[bigLen];
		int[] itersMod = new int[bigLen];
		for (int i = 0; i < toCombine.size(); i++) {
			XList<Q> c = toCombine.get(i);
			lens[i] = c.size();
		}
		itersMod[0] = 1;
		for(int i = 1; i<bigLen; i++) 
			itersMod[i] = itersMod[i-1]*lens[i-1];
		int numIters = itersMod[bigLen-1]*lens[bigLen-1];
		for (int i = 0; i<numIters; i++) {
			XList<Q> newList = new XList<>();
			for (int j = 0; j < toCombine.size(); j++) {
				XList<Q> l = toCombine.get(j);
				newList.add(l.get((i/itersMod[j])%l.size()));
			}
			result.add(newList);
		}
		return result;
	}
	
	public XList<T> clone(){
		XList<T> newList = new XList<>();
		for ( T e : this )
			newList.add(e);
		return newList;
		
	}
	
	public <R> XList<R> collect(Function<T,R> f) {
		XList<R> newList = new XList<>();
		for ( T e : this )
			newList.add(f.apply(e));
		return newList;
	}
	
	public String join(String separator) {
		try {
			if(!this.get(0).getClass().equals(separator.getClass()))
				return "";//not a list of strings
		} catch (IndexOutOfBoundsException e) {
			return ""; //also not a list of strings
		} 
		StringBuilder sb = new StringBuilder();
		int counter = 0;
		for ( T e : this) {
			sb.append(toString(e));
			counter++;
			if(counter<this.size())
				sb.append(separator);
		}
		return sb.toString();
	}
	
	public String join() {
		return this.join("");
	}
	
	private String toString(T e) {
		String s = "";
		if(e.getClass().equals(s.getClass()))
			return (String) e;
		else
			return e.toString();
	}

	public void forEachWithIndex(BiConsumer<T,Integer> f) {
		for(int i = 0; i<this.size(); i++) 
			f.accept(this.get(i),i);
	}

}
