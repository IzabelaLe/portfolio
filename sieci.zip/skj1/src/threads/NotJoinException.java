package threads;

public class NotJoinException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
