package windows;

import java.awt.Dimension;
import java.awt.GridLayout;
import java.lang.ref.Reference;
import java.lang.ref.WeakReference;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;

import main.Game;

public class GameWindow extends JFrame {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private Reference<Game> ref;
	private JComboBox<String> comboBox;

	public GameWindow(Reference<Game> g) {
		this.ref = g;
		setTitle("Gra ("+ref.get().myName+")");
		setLayout(new GridLayout(3,1));
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setPreferredSize(new Dimension(400, 200));
		
		this.comboBox = new JComboBox<>(ref.get().getPlayers());
		add(comboBox);
		JButton next = new JButton("Wyślij");
		next.addActionListener( e -> ref.get().requestTurn((String) comboBox.getSelectedItem()));
		add(next);
		JButton quit = new JButton("Zakończ grę");
		quit.addActionListener( e -> ref.get().quit());
		add(quit);
		pack();
		setVisible(true);
	}


	public void refreshComboBox() {
		GameWindow newWindow = new GameWindow(ref);
		ref.get().windowref = new WeakReference<GameWindow>(newWindow);
		this.dispose();
	}
	
}
