package zad1;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ScrollPaneConstants;
import javax.swing.table.DefaultTableModel;

public class Database {
	public static String DRIVER = "org.sqlite.JDBC";
    public static String DB_URL;
    private Connection conn;
    private Statement stat;
    private TravelData td;
    private DefaultTableModel model;
    private String[] colNames = {
    		"LOC", "COUNTRY", "DEPARTURE", "RETURN", "PRICE", "CURRENCY"
    };
    private String[][] table;
    private String[] locs = {"pl_PL", "en_US"};

	public Database(String url, TravelData travelData) {
		td = travelData;
		DB_URL = url;
	}

	public void create() {
		try {
            Class.forName(DRIVER);
        } catch (ClassNotFoundException e) {
            System.err.println("Brak sterownika JDBC");
            e.printStackTrace();
        }
		try {
            conn = DriverManager.getConnection(DB_URL);
            stat = conn.createStatement();
            
        } catch (SQLException e) {
            System.err.println("Problem z otwarciem polaczenia");
            e.printStackTrace();
        }
		
		try {
			stat.execute("CREATE TABLE IF NOT EXISTS tab "
				+ "(ID INTEGER PRIMARY KEY AUTOINCREMENT, loc varchar(10), country carchar(50), "
				+ "dep_date date, back_date date, place smallint, price real, currency varchar(3))");
		} catch (SQLException e) {
			 System.err.println("Blad przy tworzeniu tabeli");
	         e.printStackTrace();
		}
		
		for(String s : td.getData()) {
			String[] array = s.split("\\t");
			String insert = "INSERT INTO tab (loc, country, dep_date, back_date, "
					+ "place, price, currency) VALUES(";
			int count = 0;
			for(String el : array) {
				count++;
				if(count==1||count==2||count==5||count==7)
					el = "'"+el+"'";
				if(count<array.length)
					insert = insert + el + ", ";
				else 
					insert = insert + el + ");";
			}
			try {
				stat.execute(insert);
			} catch (SQLException e) {
				System.err.println("Blad insert: "+insert);
				e.printStackTrace();
			}
		}
	
		
	}

	public void showGui() {
		JFrame win = new JFrame() {
			private static final long serialVersionUID = 1L;
			
		};
		win.setSize(500, 500);
		win.setTitle("Okno startowe");
		win.setLayout(null);
		win.setResizable(false);
		win.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		query("all");
		JTable tab = new JTable(model);
		JScrollPane scroll = new JScrollPane(tab, 
				ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED, 
				ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
		scroll.setBounds(0, 50, 500, 500);
		win.add(scroll);
		JComboBox<String> menu = new JComboBox<String>(locs);
		win.add(menu);
		menu.addActionListener( e -> {
			String loc = (String) menu.getSelectedItem();
			query(loc);
		});
		win.pack();
		win.setVisible(true);
	}
	

	private void query(String loc) {
		ArrayList <String[]> result = new ArrayList<String[]>();
		try {
			ResultSet rs;
			if(loc.equals("all"))
				rs = stat.executeQuery( "Select * from tab");
			else
				rs = stat.executeQuery( "Select * from tab where loc = "+loc );
			while(rs.next()) {
			    String[] row = new String[6];
			    for (int i=0; i <6 ; i++)
			    	row[i] = rs.getString(i + 1);
			    result.add(row);
			}
		} catch (SQLException e) {
			System.err.println("Blad zapytania select");
			e.printStackTrace();
		}
		table = new String[result.size()][6];
		int count = 0;
		for(String[] row : result) {
			table[count] = row;
			count++;
		}
		model = new DefaultTableModel(table, colNames);
		//czy prawidlowy update?
	}
	
	


}
