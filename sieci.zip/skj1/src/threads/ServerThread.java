package threads;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.lang.ref.Reference;
import java.net.ServerSocket;
import java.net.Socket;

import main.Game;

public class ServerThread extends Thread {
	private ServerSocket serverSocket;
	private Reference<Game> ref;
	
	public ServerThread(Reference<Game> g) {
		this.ref = g;
		this.serverSocket = ref.get().server;
	}
	
	public void run() {
		while(true) {
			try {
				Socket s = serverSocket.accept();
				s.setSoTimeout(100000); 
				BufferedReader dIn = new BufferedReader(new InputStreamReader(s.getInputStream()));
				BufferedWriter dOut = new BufferedWriter(new OutputStreamWriter(s.getOutputStream()));
				String string = dIn.readLine();
				if(!string.equals("JOIN"))
					throw new NotJoinException();
				dOut.write("JOINCONFIRMED");
				dOut.newLine();
				dOut.flush();
				string = dIn.readLine();
				String name = string.split("/")[1];
				if(!string.split("/")[0].equals("NEWPLAYER"))
					throw new NotJoinException();
				dOut.write(ref.get().myName+serverSocket.getInetAddress().toString()+"/"+serverSocket.getLocalPort());
				for(String player : ref.get().players.keySet()) 
					dOut.write("//"+player+ref.get().players.get(player).getInetAddress().toString()+"/"+ref.get().players.get(player).getPort());
				dOut.newLine();
				dOut.flush();
				ref.get().doJoin(name, s);
			} catch (IOException e) {	
				
			} catch (NotJoinException e) {
				System.out.println("NotJoinException");
			} catch (NullPointerException e) {
				
			} 
		}
	}
}
