package join;

import main.Game;

public interface ClickFun {
	public void invoke();
	public Game getGame();
	public boolean getIfSuccess();
	
}
