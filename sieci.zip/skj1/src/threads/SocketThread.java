package threads;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.lang.ref.Reference;
import java.net.Socket;

import main.Game;

public class SocketThread extends Thread {
	private Socket s;
	private Reference<Game> ref;

	public SocketThread(Socket s, Reference<Game> ref) {
		this.s = s;
		this.ref = ref;
	}
	
	public void run() {
		try {
			BufferedReader dIn = new BufferedReader(new InputStreamReader(s.getInputStream()));
			String data;
			while(true) {
				data = dIn.readLine();
				System.out.println("Socket "+s.getPort()+" received: "+data);
				try {
					if(data.startsWith("NEWPLAYER")) {
						String[] s = data.split("/");
						Socket newSocket = new Socket(s[2], Integer.parseInt(s[3]));
						ref.get().addPlayer(s[1], newSocket);
					}
					if(data.equals("QUIT")) {
						String name = null;
						for ( String pName : ref.get().players.keySet()) {
							if(this.s.equals(ref.get().players.get(pName)))
								name = pName;
						}
						try {
							ref.get().doQuit(name);
						} catch (NullPointerException e) {	}
					}
					if(data.equals("PLAY")) {
						String name = null;
						for ( String pName : ref.get().players.keySet()) {
							if(this.s.equals(ref.get().players.get(pName)))
								name = pName;
						}
						ref.get().toPlayQueue.add(name);
						BufferedWriter dOut = new BufferedWriter(new OutputStreamWriter(s.getOutputStream()));
						dOut.write("TURNCONFIRMED");
						dOut.newLine();
						dOut.flush();
					}
					if(data.equals("TURNCONFIRMED")) {
						String name = null;
						for ( String pName : ref.get().players.keySet()) {
							if(this.s.equals(ref.get().players.get(pName)))
								name = pName;
						}
						ref.get().toPlayQueue.add(name);
					}
				} catch (NullPointerException e) {	}
			}
		} catch (IOException e) {	}
	}
}
