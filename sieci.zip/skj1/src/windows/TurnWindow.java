package windows;

import java.awt.Dimension;
import java.awt.GridLayout;
import java.lang.ref.Reference;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

import main.Turn;

public class TurnWindow extends JFrame {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public TurnWindow(Reference<Turn> turnref, String opponentName) {
		setTitle("Tura z "+opponentName);
		setLayout(new GridLayout(3,1));
		setResizable(false);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		this.setPreferredSize(new Dimension(400,160));
		JTextField textEditor = new JTextField();
		add(textEditor);
		JLabel editorLabel = new JLabel("Podaj swoja liczbę");
		editorLabel.setLabelFor(textEditor);
		add(editorLabel);
		JButton next = new JButton("Wyślij");
		next.addActionListener( e -> {
			try {
				turnref.get().setMyNum(Integer.parseInt(textEditor.getText()));
				turnref.get().sendMyNum();
			} catch (NumberFormatException e1) {
				@SuppressWarnings("unused")
				ErrorWindow ew = new ErrorWindow("Podaj prawidłową liczbę całkowitą");
			}
		});
		add(next);
		pack();
		setVisible(true);
		
	}
}
